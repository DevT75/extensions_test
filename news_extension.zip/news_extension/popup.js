const API_KEY = '0f1a193228944dc1b10389d8e3081c4f';

const API_URL = `https://newsapi.org/v2/top-headlines?country=us&apiKey=${API_KEY}`;

function displayNews(articles) {
  const newsList = document.getElementById('news-list');
  newsList.innerHTML = ''; // Clear existing content

  if (!articles || articles.length === 0) {
    const li = document.createElement('li');
    li.textContent = 'No news articles available at the moment.';
    newsList.appendChild(li);
    return;
  }

  articles.forEach(article => {
    if (article.title && article.url) {
      const li = document.createElement('li');
      const a = document.createElement('a');
      a.href = article.url;
      a.target = '_blank';
      a.textContent = article.title;
      li.appendChild(a);
      newsList.appendChild(li);
    }
  });
}

function displayError(message) {
  const newsList = document.getElementById('news-list');
  newsList.innerHTML = `<li style="color: red;">${message}</li>`;
}

fetch(API_URL)
  .then(response => {
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    return response.json();
  })
  .then(data => {
    if (data.status === 'ok' && Array.isArray(data.articles)) {
      displayNews(data.articles.slice(0, 5));
    } else {
      throw new Error('Invalid API response format');
    }
  })
  .catch(error => {
    console.error('Error fetching news:', error);
    displayError('Failed to fetch news. Please try again later.');
  });